﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication9
{
    public enum BlenderModes
    {
        Normal = 1,
        Super
    }
}